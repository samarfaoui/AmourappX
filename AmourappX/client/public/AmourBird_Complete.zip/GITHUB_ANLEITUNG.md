# GitHub Actions - Automatischer APK & IPA Build

Mit GitHub Actions werden APK (Android) und IPA (iOS) automatisch gebaut - kostenlos!

---

## Schritt 1: GitHub Repository erstellen

1. Gehe zu: https://github.com/new
2. Repository Name: `AmourBird`
3. Visibility: **Public** (kostenlose Builds) oder **Private**
4. Klicke **"Create repository"**

---

## Schritt 2: Projekt zu GitHub hochladen

### Option A: GitHub Desktop (einfacher)
1. Installiere GitHub Desktop: https://desktop.github.com
2. Klicke **"Add" → "Add Existing Repository"**
3. Wähle den entpackten AmourBird Ordner
4. Klicke **"Publish repository"**

### Option B: Terminal/Git
```bash
cd AmourBird
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/DEIN_USERNAME/AmourBird.git
git push -u origin main
```

---

## Schritt 3: Build starten

1. Gehe zu deinem Repository auf GitHub
2. Klicke auf **"Actions"** Tab
3. Der Build startet automatisch bei jedem Push
4. Oder klicke **"Run workflow"** für manuellen Start

---

## Schritt 4: APK & IPA herunterladen

Nach ca. 10-15 Minuten:

1. Gehe zu **"Actions"** Tab
2. Klicke auf den letzten Workflow-Run
3. Scrolle nach unten zu **"Artifacts"**
4. Lade herunter:
   - **AmourBird-Android-APK** - Für BrowserStack Android
   - **AmourBird-iOS-IPA** - Für BrowserStack iOS (Simulator)

---

## Für echte iOS-Geräte (optional)

Für Tests auf echten iPhones brauchst du Apple Developer Zertifikate.

### Secrets in GitHub hinzufügen:
1. Repository → **Settings** → **Secrets and variables** → **Actions**
2. Klicke **"New repository secret"**
3. Füge hinzu:
   - `IOS_CERTIFICATE_BASE64` - Dein .p12 Zertifikat (base64)
   - `IOS_CERTIFICATE_PASSWORD` - Zertifikat-Passwort
   - `IOS_PROVISIONING_PROFILE_BASE64` - Provisioning Profile (base64)

### Zertifikat zu Base64 konvertieren (auf Mac):
```bash
base64 -i certificate.p12 | pbcopy
```

---

## Build-Zeiten

| Plattform | Ungefähre Zeit |
|-----------|----------------|
| Android APK | 5-8 Minuten |
| iOS IPA (Simulator) | 8-12 Minuten |
| iOS IPA (Signed) | 10-15 Minuten |

---

## Kostenlos für:

- **Public Repositories**: Unbegrenzte Builds
- **Private Repositories**: 2.000 Minuten/Monat kostenlos

---

## BrowserStack Testing

Nach dem Download:

1. Gehe zu https://www.browserstack.com
2. Öffne **App Live**
3. Klicke **"Upload App"**
4. Wähle die APK oder IPA Datei
5. Wähle Geräte aus und teste!

---

## Fehlerbehebung

### Build schlägt fehl?
- Prüfe die Logs im Actions Tab
- Stelle sicher, dass alle Dateien commited sind

### iOS Build funktioniert nicht?
- Die Simulator-IPA funktioniert nur in BrowserStack Simulatoren
- Für echte Geräte brauchst du Apple Developer Zertifikate

---

## Zusammenfassung

1. Projekt zu GitHub pushen
2. Actions Tab öffnen
3. Warten (10-15 Min)
4. APK/IPA herunterladen
5. Auf BrowserStack hochladen
6. Testen!

Viel Erfolg!

# AmourBird Hybrid-App Build & Test Anleitung

## Schritt 1: Projekt herunterladen

1. In Replit: Klicke auf die **drei Punkte** (oben rechts)
2. Wähle **"Download as ZIP"**
3. Entpacke die ZIP-Datei auf deinem PC

---

## Schritt 2: Entwicklungsumgebung installieren

### Für Android (Windows/Mac/Linux):
1. Gehe zu: https://developer.android.com/studio
2. Lade Android Studio herunter
3. Installiere es (dauert ca. 10-15 Min)

### Für iOS (nur Mac):
1. Öffne App Store auf deinem Mac
2. Installiere **Xcode** (kostenlos)
3. Apple Developer Account (99€/Jahr) für App Store

---

## Schritt 3: Projekt vorbereiten

### Windows (Doppelklick):
Führe `windows_starter/START.bat` aus

### Mac/Linux (Terminal):
```bash
# Node.js Pakete installieren
npm install

# Projekt bauen
npm run build

# Spieledateien kopieren
cp -r client/public/AmourBird.html dist/public/
cp -r client/public/AmourBird1.html dist/public/
cp -r client/public/generated_images dist/public/

# Capacitor synchronisieren
npx cap sync android
npx cap sync ios
```

---

## Schritt 4: APK bauen (Android)

### Option A: Mit Android Studio (einfacher)
1. Öffne Android Studio
2. Klicke **"Open"** und wähle den `android` Ordner
3. Warte bis Gradle fertig ist
4. Menü: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. APK: `android/app/build/outputs/apk/debug/app-debug.apk`

### Option B: Mit Terminal
```bash
cd android
./gradlew assembleDebug
```

---

## Schritt 5: IPA bauen (iOS - nur Mac)

1. Öffne Terminal im Projektordner
2. Führe aus:
```bash
npx cap sync ios
npx cap open ios
```
3. Xcode öffnet sich
4. Wähle oben links dein Gerät/Simulator
5. Menü: **Product → Archive** (für IPA)
6. Im Organizer: **Distribute App → Ad Hoc** für Test-IPA

---

## Schritt 6: BrowserStack Testing

### 6.1 Account erstellen
1. Gehe zu: https://www.browserstack.com
2. Registriere dich (kostenlose Testversion verfügbar)

### 6.2 App hochladen
1. Gehe zu **App Live** (im Dashboard)
2. Klicke **"Upload App"**
3. Wähle deine Datei:
   - Android: `app-debug.apk`
   - iOS: `AmourBird.ipa`

### 6.3 Testen
1. Wähle ein Gerät aus der Liste:
   - Samsung Galaxy S23, S22, S21...
   - iPhone 15, 14, 13...
   - Pixel 8, 7, 6...
2. Klicke **"Start Session"**
3. Die App öffnet sich auf dem echten Gerät
4. Teste alle Funktionen manuell

### 6.4 Was du testen solltest
- Alle 5 Level durchspielen
- Level Infinity testen
- Touch-Eingabe prüfen
- Sound (falls vorhanden)
- Verschiedene Bildschirmgrößen
- Android UND iOS Geräte

---

## Schritt 7: Firebase Test Lab (Alternative)

### Firebase-Projekt erstellen
1. Gehe zu: https://console.firebase.google.com
2. Klicke **"Projekt hinzufügen"**
3. Projektname: `AmourBird`

### APK hochladen
1. Linkes Menü → **"Test Lab"**
2. Klicke **"Test ausführen"**
3. Wähle **"Robo-Test"** (automatisch)
4. Wähle Geräte aus
5. Klicke **"Test starten"**

### Kostenlos pro Tag:
- 5 Tests auf virtuellen Geräten
- 5 Tests auf physischen Geräten

---

## Fehlerbehebung

### Android: Gradle-Fehler
```bash
cd android
./gradlew clean
./gradlew assembleDebug
```

### Android: SDK nicht gefunden
- Android Studio → Tools → SDK Manager
- Installiere Android SDK 34

### iOS: CocoaPods-Fehler
```bash
sudo gem install cocoapods
cd ios/App
pod install
```

### iOS: Signing-Fehler
- Xcode → Signing & Capabilities
- Wähle dein Team/Account

---

## Zusammenfassung

### Android APK bauen:
```bash
npm install
npm run build
npx cap sync android
cd android && ./gradlew assembleDebug
```
**APK:** `android/app/build/outputs/apk/debug/app-debug.apk`

### iOS IPA bauen (nur Mac):
```bash
npm install
npm run build
npx cap sync ios
npx cap open ios
# In Xcode: Product → Archive
```

### BrowserStack testen:
1. https://www.browserstack.com → App Live
2. APK/IPA hochladen
3. Gerät wählen → Start Session
4. Manuell testen

Viel Erfolg beim Testen!
